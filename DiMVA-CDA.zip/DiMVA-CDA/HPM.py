import torch
import torch.nn as nn
import random
import numpy as np
import scipy.sparse as sp

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

set_seed(42)
rng_global = np.random.RandomState(42)

# Function to convert sparse matrix to edge index (extended version)
def sp_to_edge_index_ext(sp_sub, device):
    if hasattr(sp_sub, "tocoo"):
        coo = sp_sub.tocoo()
        if coo.nnz == 0:
            return torch.zeros((2, 0), dtype=torch.long, device=device)
        ei = np.vstack([coo.row, coo.col])
        return torch.as_tensor(ei, dtype=torch.long, device=device)

    arr = np.asarray(sp_sub)
    r, c = np.where(arr > 0)
    ei = np.vstack([r, c])
    return torch.as_tensor(ei, dtype=torch.long, device=device)

def mine_hard_positives(model, X_pool_t: torch.Tensor, A_pool, device,
                           tau_hi=0.95, tau_lo=0.8, step_idx=0, total_steps=8,
                           max_add=32, edge_keep=0.9, noise_std=0.02, T=1.0):

    n = X_pool_t.size(0)
    if n == 0:
        return []

    def one_view():
        A = A_pool
        if hasattr(A, "tocoo"):
            coo = A.tocoo()
            m = int(coo.nnz * edge_keep)
            if m > 0 and m < coo.nnz:
                sel = rng_global.choice(coo.nnz, size=m, replace=False)
                A_view = sp.csr_matrix((coo.data[sel], (coo.row[sel], coo.col[sel])), shape=A.shape)
            else:
                A_view = A
        else:
            A_view = A
        ei = sp_to_edge_index_ext(A_view, device)

        model.train()
        x = X_pool_t + noise_std * torch.randn_like(X_pool_t)
        logits = model(x, ei, None).view(-1)
        probs = torch.sigmoid(logits / float(T)).detach().cpu().numpy()
        return probs

    t = (step_idx + 1) / float(total_steps)
    tau = tau_hi - (tau_hi - tau_lo) * t

    pA = one_view()
    pB = one_view()

    mask = ((pA >= tau) | (pB >= tau))
    idx = np.where(mask)[0]

    if len(idx) > max_add:
        conf = (pA[idx] + pB[idx]) * 0.5
        topk = np.argsort(-conf)[:max_add]
        idx = idx[topk]

    return idx.tolist()
