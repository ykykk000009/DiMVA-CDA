import math
import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F
import scipy.sparse as sp
from torch_geometric.nn import GATConv, GCNConv
import random

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

set_seed(42)

def _pair_index_to_ij(k, n_dis):
    i = k // n_dis
    j = k % n_dis
    return i, j

def build_pair_adj_from_knn(pairs_local: np.ndarray,
                            A_circ: sp.coo_matrix,
                            A_dis: sp.coo_matrix) -> sp.coo_matrix:
    """
        Build the pairwise adjacency matrix for circRNA-disease pairs:
        1. Link circRNA neighbors (based on `A_circ`) and disease neighbors (based on `A_dis`).
        2. Ensure symmetry and eliminate any invalid entries.
    """
    local_N = pairs_local.shape[0]
    key2idx = {(int(i), int(j)): idx for idx, (i, j) in enumerate(pairs_local)}

    A = sp.lil_matrix((local_N, local_N), dtype=np.float32)

    A_circ_csr = A_circ.tocsr()
    A_dis_csr  = A_dis.tocsr()

    added_self_loops = set()

    for u_idx, (i, j) in enumerate(pairs_local):
        i = int(i)
        j = int(j)

        if (i, j) not in added_self_loops:
            A[u_idx, u_idx] = 1.0
            added_self_loops.add((i, j))

        circ_neighbors = A_circ_csr.indices[A_circ_csr.indptr[i]:A_circ_csr.indptr[i + 1]]
        for i2 in circ_neighbors:
            v = key2idx.get((int(i2), j), None)
            if v is not None and v != u_idx:
                A[u_idx, v] = 1.0

        dis_neighbors = A_dis_csr.indices[A_dis_csr.indptr[j]:A_dis_csr.indptr[j + 1]]
        for j2 in dis_neighbors:
            v = key2idx.get((i, int(j2)), None)
            if v is not None and v != u_idx:
                A[u_idx, v] = 1.0

    A = A.tocsr()
    A = A.maximum(A.T)

    A.setdiag(0)
    A.eliminate_zeros()

    return A.tocoo()

def topk_binary_adj(sim: np.ndarray, k: int) -> sp.coo_matrix:
    """
    Generate a binary adjacency matrix based on top-k similarities.
    1. Zero out the diagonal (no self-loops).
    2. Select the top-k most similar nodes for each node.
    """
    sim = sim.copy()
    np.fill_diagonal(sim, 0.0)
    N = sim.shape[0]
    idx_topk = np.argpartition(-sim, kth=min(k, N-1), axis=1)[:, :k]
    rows = np.repeat(np.arange(N), k)
    cols = idx_topk.reshape(-1)
    data = np.ones_like(rows, dtype=np.float32)
    A = sp.coo_matrix((data, (rows, cols)), shape=(N, N), dtype=np.float32)
    A = A.maximum(A.T)
    A.setdiag(0)
    A.eliminate_zeros()

    return A

class GCN(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, heads, pos_prior, hr, fc):
        super(GCN, self).__init__()

        self.view_dim = input_dim // 3
        self.conv1 = GATConv(
            in_channels=input_dim,
            out_channels=hidden_dim,
            heads=heads,
            concat=False,
            dropout=0.1
        )
        self.conv2 = GCNConv(hidden_dim, hidden_dim)

        self.Wc = nn.Linear(hidden_dim + self.view_dim, hidden_dim)
        self.Wd = nn.Linear(hidden_dim + self.view_dim, hidden_dim)
        self.Wcd = nn.Linear(hidden_dim + self.view_dim, hidden_dim)

        self.ln_c = nn.LayerNorm(hidden_dim)
        self.ln_d = nn.LayerNorm(hidden_dim)
        self.ln_i = nn.LayerNorm(hidden_dim)

        self.fc2 = nn.Linear(hidden_dim, 3 * hidden_dim)
        self.ln_fuse = nn.LayerNorm(3 * hidden_dim)
        self.fc3 = nn.Linear(3 * hidden_dim, output_dim)

        self.hr = nn.Parameter(torch.tensor(0.1))
        self.fc = nn.Parameter(torch.tensor(0.1))

        self._reset_parameters(pos_prior)

    def _reset_parameters(self, pos_prior):
        """
        Initialize the model parameters using Xavier uniform initialization.
        Set the bias of the output layer based on pos_prior if provided.
        """
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

        if pos_prior is not None and 0.0 < pos_prior < 1.0:
            pos_prior = float(max(min(pos_prior, 1.0 - 1e-6), 1e-6))
            bias_value = math.log(pos_prior / (1.0 - pos_prior))
            self.fc3.bias.data.fill_(bias_value)
        else:
            nn.init.zeros_(self.fc3.bias)

    def forward(self, x, edge_index, edge_weight=None):
        """
        Forward pass through the GCN model:
        1. Apply GATConv and GCNConv layers for graph convolution.
        2. Concatenate circRNA, disease, and interaction views with the graph embeddings.
        3. Compute attention scores and apply the weighted fusion of views.
        4. Pass through fully connected layers for final prediction.
        """
        h = self.conv1(x, edge_index)
        h = F.elu(h)
        h_res = h
        h = self.conv2(h, edge_index, edge_weight)
        h = h + 0.5 * h_res
        h = F.elu(h)

        """VA"""
        x_circ  = x[:, 0 * self.view_dim : 1 * self.view_dim]        # circRNA view
        x_dis   = x[:, 1 * self.view_dim : 2 * self.view_dim]        # disease view
        x_inter = x[:, 2 * self.view_dim : 3 * self.view_dim]        # interaction view

        circ_in  = torch.cat([h, x_circ],  dim=-1)
        dis_in   = torch.cat([h, x_dis],   dim=-1)
        inter_in = torch.cat([h, x_inter], dim=-1)

        # Linear transformations and layer normalization
        F_circ  = self.ln_c(F.gelu(self.Wc(circ_in)))
        F_dis   = self.ln_d(F.gelu(self.Wd(dis_in)))
        F_inter = self.ln_i(F.gelu(self.Wcd(inter_in)))

        attn_scores = torch.softmax(torch.stack([
            (F_circ * F_dis).sum(dim=1),
            (F_circ * F_inter).sum(dim=1),
            (F_dis  * F_inter).sum(dim=1),
        ], dim=1), dim=1)  # Attention for view fusion

        F_circ  = F_circ  * attn_scores[:, 0:1]
        F_dis   = F_dis   * attn_scores[:, 1:2]
        F_inter = F_inter * attn_scores[:, 2:3]

        F_concat = torch.cat([F_circ, F_dis, F_inter], dim=-1)

        h_resized = self.fc2(h)
        hr_weight = torch.sigmoid(self.hr)
        fc_weight = torch.sigmoid(self.fc)
        fused = hr_weight * h_resized + fc_weight * F_concat
        h = self.ln_fuse(fused)

        logits = self.fc3(h).view(-1)

        return logits
