import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_curve, average_precision_score

def plot_roc_all_folds(all_folds_roc, k_folds, title, filename):
    plt.figure()
    colors = ['#9CC3E5', '#ECCAB7', '#527865', 'gray', '#C4967B']
    aucs_per_fold = []

    all_fpr = np.unique(
        np.concatenate([np.ravel(fpr) for fpr, _, _ in all_folds_roc])
    )
    all_fpr.sort()
    mean_tpr = np.zeros_like(all_fpr, dtype=float)

    for fold in range(k_folds):
        fpr, tpr, auc = all_folds_roc[fold]

        fpr = np.ravel(fpr)
        tpr = np.ravel(tpr)

        order = np.argsort(fpr)
        fpr = fpr[order]
        tpr = tpr[order]

        aucs_per_fold.append(float(auc))

        mean_tpr += np.interp(all_fpr, fpr, tpr)

        plt.plot(
            fpr, tpr,
            linestyle='--',
            color=colors[fold],
            label=f"Fold {fold + 1} (AUC: {auc:.4f})"
        )

    mean_tpr /= k_folds
    auc_mean_curve = np.trapz(mean_tpr, all_fpr)

    plt.plot(
        all_fpr, mean_tpr,
        linestyle='-',
        color='#D98777',
        linewidth=1.5,
        label=f"Mean ROC (AUC: {np.mean(aucs_per_fold):.4f})"
    )

    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(filename, dpi=600, format='eps')
    plt.savefig(filename.replace('.eps', '.png'), dpi=600, format='png')
    plt.close()

    return aucs_per_fold, float(np.mean(aucs_per_fold))

def plot_pr_all_folds(pr_data, recall_data, aupr_folds, k_folds, title, filename):

    plt.figure()
    colors = ['#9CC3E5', '#ECCAB7', '#527865', 'gray', '#C4967B']

    for fold in range(k_folds):
        rec = np.ravel(recall_data[fold])
        prec = np.ravel(pr_data[fold])

        sort_idx = np.argsort(rec)
        rec = rec[sort_idx]
        prec = prec[sort_idx]

        aupr = aupr_folds[fold]

        plt.plot(
            rec, prec,
            linestyle='--',
            color=colors[fold],
            label=f"Fold {fold+1} (AUPR={aupr:.4f})"
        )

    all_rec = np.unique(np.concatenate([np.ravel(r) for r in recall_data]))
    all_rec.sort()

    mean_prec = np.zeros_like(all_rec)

    for fold in range(k_folds):
        rec = np.ravel(recall_data[fold])
        prec = np.ravel(pr_data[fold])

        sort_idx = np.argsort(rec)
        rec = rec[sort_idx]
        prec = prec[sort_idx]

        mean_prec += np.interp(all_rec, rec, prec)

    mean_prec /= k_folds
    mean_aupr = float(np.mean(aupr_folds))

    plt.plot(
        all_rec, mean_prec,
        linestyle='-',
        color='#D98777',
        linewidth=1.5,
        label=f"Mean PR (AUPR: {mean_aupr:.4f})"
    )

    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title(title)
    plt.legend()
    plt.tight_layout()

    plt.savefig(filename, dpi=600, format='eps')
    plt.savefig(filename.replace('.eps', '.png'), dpi=600)
    plt.close()

    return aupr_folds, mean_aupr

# ROC
roc_df = pd.read_csv("C2D_roc_data.csv")

all_folds_roc = []
for fold in roc_df['fold'].unique():
    fold_data = roc_df[roc_df['fold'] == fold]
    fpr = fold_data['fpr'].values
    tpr = fold_data['tpr'].values
    auc = fold_data['auc'].values[0]
    all_folds_roc.append((fpr, tpr, auc))

plot_roc_all_folds(
    all_folds_roc=all_folds_roc,
    k_folds=len(all_folds_roc),
    title="circ2Disease 5-CV ROC",
    filename="C2D_roc_curves.eps"
)

#  PR
pr_df = pd.read_csv("C2D_pr_data.csv")
pr_data = []
recall_data = []
aupr_folds = []

for fold in sorted(pr_df['fold'].unique()):
    fold_data = pr_df[pr_df['fold'] == fold]
    rec = fold_data['recall'].values.astype(float)
    prec = fold_data['precision'].values.astype(float)
    aupr = float(fold_data['aupr'].iloc[0])
    pr_data.append(prec)
    recall_data.append(rec)
    aupr_folds.append(aupr)

plot_pr_all_folds(
    pr_data=pr_data,
    recall_data=recall_data,
    aupr_folds=aupr_folds,
    k_folds=len(pr_data),
    title="circ2Disease 5-CV PR",
    filename="C2D_pr_curves.eps"
)

