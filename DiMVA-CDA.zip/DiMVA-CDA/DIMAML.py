import math
import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F
from collections import OrderedDict
import torch.optim as optim
import collections
from sklearn.metrics import precision_recall_curve, f1_score, roc_auc_score, average_precision_score, \
    accuracy_score, recall_score, precision_score, matthews_corrcoef, confusion_matrix
import random

# Set random seed for reproducibility
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

set_seed(42)

try:
    from torch.func import functional_call
except ImportError:
    from torch.nn.utils.stateless import functional_call

_DOS_STATE = {
    "prec_hist": collections.deque(maxlen=128),
    "rec_hist":  collections.deque(maxlen=128),
}

class MAML:
    def __init__(self, model, inner_lr, outer_lr, inner_steps,
                 device, pos_weight):
        self.model = model
        self.inner_lr = inner_lr
        self.outer_lr = outer_lr
        self.inner_steps = inner_steps
        self.device = device
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.outer_lr, weight_decay=1e-4)
        self.pos_weight = pos_weight
        self._build_param_groups()

        if pos_weight is not None:
            self.criterion = nn.BCEWithLogitsLoss(
                pos_weight=torch.tensor([pos_weight], dtype=torch.float32, device=device)
            )
            print(f"[INIT] Using BCEWithLogitsLoss with pos_weight={pos_weight:.3f}")
        else:
            self.criterion = nn.BCEWithLogitsLoss()
            print(f"[INIT] Using BCEWithLogitsLoss without weighting")

    def reptile_update(self, theta_prime_state, beta):
        """
        Reptile outer loop update: θ ← θ + β(θ' - θ)
        theta_prime_state: fast adapted state_dict()
        """
        with torch.no_grad():
            for name, param in self.model.named_parameters():
                if name in theta_prime_state:
                    diff = theta_prime_state[name] - param
                    param.add_(beta * diff)

    def _build_param_groups(self):
        """
        Group parameters into three categories:
          - disease_param_names: Parameters related to disease perspective (Wd, ln_d, s_d)
          - circ_param_names: Parameters related to circRNA perspective (Wc, ln_c, s_c)
          - shared_param_names: Other parameters that are updated by both inner loops
        """
        self.disease_param_names = []
        self.circ_param_names = []
        self.shared_param_names = []

        for name, p in self.model.named_parameters():
            if any(tag in name for tag in ["Wd", "ln_d", "s_d"]):
                self.disease_param_names.append(name)
            elif any(tag in name for tag in ["Wc", "ln_c", "s_c"]):
                self.circ_param_names.append(name)
            else:
                self.shared_param_names.append(name)

        print("[MAML] param groups built:",
              f"disease={len(self.disease_param_names)},",
              f"circ={len(self.circ_param_names)},",
              f"shared={len(self.shared_param_names)}")

    def _to_1d(self, t):
        if t is None:
            return t
        if isinstance(t, np.ndarray):
            t = torch.tensor(t, dtype=torch.float32, device=self.device)
        if t.dim() > 1 and t.size(-1) == 1:
            return t.view(-1)
        return t.view(-1)

    def _loss_fn(self, logits, labels):
        """
        Binary cross-entropy loss with regularization.
        """
        bce = F.binary_cross_entropy_with_logits(logits, labels.float())
        reg = 2e-4 * (logits ** 2).mean()
        return bce + reg

    def adapt_task(self, X_task, y_task, support_idx, query_idx, edge_index, edge_weight):
        """
        Dual-level inner-loop adaptation for a single task:
        - Inner loop 1 (disease-level): Update disease + shared parameters
        - Inner loop 2 (circRNA-level): Update circ + shared parameters (after disease-level update)

        Then compute meta-loss on the query set and return the first-order approximation of the meta-gradient.
        """

        # 1) Initial parameters θ
        init_params = OrderedDict((name, p) for name, p in self.model.named_parameters())
        fast_weights = OrderedDict((name, p) for name, p in init_params.items())

        y_task_flat = y_task.view(-1)
        sup_idx = support_idx
        qry_idx = query_idx

        grads_d_all = []
        grads_c_all = []

        for _ in range(self.inner_steps):
            # ========== inner step 1: disease-level update ==========
            logits_all_d = functional_call(self.model, fast_weights, (X_task, edge_index, edge_weight)).view(-1)
            sup_out_d = logits_all_d[sup_idx]
            sup_lbl = y_task_flat[sup_idx].float()
            loss_d = self._loss_fn(sup_out_d, sup_lbl)

            # Calculate gradients only for disease + shared parameters
            params_d = []
            name_d = []
            for name, w in fast_weights.items():
                if (name in self.disease_param_names or name in self.shared_param_names) and w.requires_grad:
                    params_d.append(w)
                    name_d.append(name)

            grads_d = torch.autograd.grad(
                loss_d,
                params_d,
                create_graph=True,
                retain_graph=True,
                allow_unused=True
            )
            grads_d_all.append(grads_d)

            # Update θ_d (first inner loop: disease-level)
            theta_d = OrderedDict()
            idx = 0
            for name, w in fast_weights.items():
                if name in self.disease_param_names or name in self.shared_param_names:
                    g = grads_d[idx]
                    idx += 1
                    if g is None:
                        theta_d[name] = w
                    else:
                        theta_d[name] = w - self.inner_lr * g
                else:
                    theta_d[name] = w

            # ========== inner step 2: circRNA-level update ==========
            logits_all_c = functional_call(self.model, theta_d, (X_task, edge_index, edge_weight)).view(-1)
            sup_out_c = logits_all_c[sup_idx]
            loss_c = self._loss_fn(sup_out_c, sup_lbl)

            # Calculate gradients only for circRNA + shared parameters
            params_c = []
            name_c = []
            for name, w in theta_d.items():
                if (name in self.circ_param_names or name in self.shared_param_names) and w.requires_grad:
                    params_c.append(w)
                    name_c.append(name)

            grads_c = torch.autograd.grad(
                loss_c,
                params_c,
                create_graph=True,
                retain_graph=True,
                allow_unused=True
            )
            grads_c_all.append(grads_c)

            # Update θ_c (second inner loop: circRNA-level)
            fast_new = OrderedDict()
            idx_c = 0
            for name, w in theta_d.items():
                if name in name_c:
                    g = grads_c[idx_c]
                    idx_c += 1
                    if g is None:
                        fast_new[name] = w
                    else:
                        fast_new[name] = w - self.inner_lr * g
                else:
                    fast_new[name] = w

            fast_weights = fast_new

        # ========== Outer loop: compute meta-loss on query ==========
        logits_all_q = functional_call(self.model, fast_weights, (X_task, edge_index, edge_weight)).view(-1)
        query_out = logits_all_q[qry_idx]
        query_lbl = y_task_flat[qry_idx].float()
        query_loss = self._loss_fn(query_out, query_lbl)

        # ---- Update dynamic_pos_ratio state using query performance ----
        with torch.no_grad():
            probs_q = torch.sigmoid(query_out)
            y_true_q = query_lbl.detach().cpu().numpy()
            y_pred_q = (probs_q.detach().cpu().numpy() >= 0.5).astype(int)
            try:
                prec = precision_score(y_true_q, y_pred_q, zero_division=0)
                rec = recall_score(y_true_q, y_pred_q, zero_division=0)
            except Exception:
                prec, rec = 0.0, 0.0
            _DOS_STATE["prec_hist"].append(float(prec))
            _DOS_STATE["rec_hist"].append(float(rec))

        param_list = [p for p in fast_weights.values() if p.requires_grad]
        grads_q = torch.autograd.grad(
            query_loss,
            param_list,
            create_graph=False,
            retain_graph=False,
            allow_unused=True
        )

        grad_map_q = {}
        grad_counter = 0
        for name, p in fast_weights.items():
            if p.requires_grad:
                grad_map_q[name] = grads_q[grad_counter]
                grad_counter += 1
            else:
                grad_map_q[name] = None

        grads_out = []
        for name, p in init_params.items():
            g = grad_map_q.get(name, None)
            if g is None:
                grads_out.append(torch.zeros_like(p))
            else:
                g = g.to(p.device, dtype=p.dtype)
                grads_out.append(g)

        return grads_out, query_loss.item(), fast_weights, grads_d_all, grads_c_all

    def meta_update(self, grads_avg):
        """
        Update the model parameters using the meta-gradient from the outer loop.
        """
        for (name, p), g in zip(self.model.named_parameters(), grads_avg):
            if g is None:
                continue
            if not torch.is_tensor(g):
                g = torch.as_tensor(g, device=p.device, dtype=p.dtype)
            else:
                if g.device != p.device:
                    g = g.to(p.device, non_blocking=True)
                if g.dtype != p.dtype:
                    g = g.to(p.dtype)

            if p.grad is None:
                p.grad = g.clone()
            else:
                p.grad.copy_(g)

        for group in self.optimizer.param_groups:
            for p in group["params"]:
                if p.grad is not None and p.grad.device != p.device:
                    p.grad.data = p.grad.data.to(p.device, non_blocking=True)

        with torch.no_grad():
            for n, p in self.model.named_parameters():
                if "fc3.weight" in n:
                    before = p.detach().clone()
                    break

        self.optimizer.step()
        self.optimizer.zero_grad()
