Number of unique circRNAs: 1107
Number of unique diseases: 137
Number of associations: 1172