irc2Disease4
Number of unique circRNAs: 249
Number of unique diseases: 54
Number of associations: 267
249*54=13446

54*4=432
