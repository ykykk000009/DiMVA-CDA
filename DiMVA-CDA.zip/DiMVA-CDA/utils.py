import matplotlib.pyplot as plt
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score, recall_score, average_precision_score, precision_recall_curve, roc_curve
import numpy as np
import pandas as pd
def save_roc_pr_to_csv(all_folds_roc, pr_data, recall_data, aupr_folds, filename_suffix=""):
    # ===== ROC =====
    roc_records = []
    for fold, (fpr, tpr, auc) in enumerate(all_folds_roc, start=1):
        for f, t in zip(fpr, tpr):
            roc_records.append({'fold': fold, 'fpr': f, 'tpr': t, 'auc': auc})
    roc_df = pd.DataFrame(roc_records)
    roc_df.to_csv(f"roc_data_{filename_suffix}.csv", index=False)

    # ===== PR  =====
    pr_records = []
    for fold, (precision_arr, recall_arr, aupr) in enumerate(zip(pr_data, recall_data, aupr_folds), start=1):
        prec = np.ravel(precision_arr)
        rec  = np.ravel(recall_arr)

        sort_idx = np.argsort(rec)
        rec = rec[sort_idx]
        prec = prec[sort_idx]

        for p, r in zip(prec, rec):
            pr_records.append({
                'fold': fold,
                'recall': float(r),
                'precision': float(p),
                'aupr': float(aupr)
            })

    pr_df = pd.DataFrame(pr_records)
    pr_df.to_csv(f"pr_data_{filename_suffix}.csv", index=False)
